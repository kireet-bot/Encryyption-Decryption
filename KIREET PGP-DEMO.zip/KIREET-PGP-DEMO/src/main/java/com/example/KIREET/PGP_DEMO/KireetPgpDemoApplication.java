package com.example.KIREET.PGP_DEMO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KireetPgpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KireetPgpDemoApplication.class, args);
	}

}
